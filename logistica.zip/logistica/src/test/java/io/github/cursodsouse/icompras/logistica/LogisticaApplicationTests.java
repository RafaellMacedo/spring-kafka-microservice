package io.github.cursodsouse.icompras.logistica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LogisticaApplicationTests {

	@Test
	void contextLoads() {
	}

}
